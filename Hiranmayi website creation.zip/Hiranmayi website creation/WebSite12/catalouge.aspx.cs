﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class catalouge : System.Web.UI.Page
{
    //Linq query used to retrieve the data from database

    protected void Page_Load(object sender, EventArgs e)
    {
        DataClassesDataContext db = new DataClassesDataContext();
        Grid.DataSource = db.productsts;
        Grid.DataBind();
    }
    //on button click data is retrieved based on the users dropdown list index selection and category id.category id is mapped to dropdown list values.
    protected void button1_Click(object sender, EventArgs e)
    {
        DataClassesDataContext db = new DataClassesDataContext();
        
        //for the selection of all 

        if (dropdownlist1.SelectedValue == "0")
        {

            Grid.DataSource = db.productsts;
            Grid.DataBind();
        }
        //for the selection of teddy bears
        else if (dropdownlist1.SelectedValue == "1")
        {
            var fbs = from fb in db.productsts
                      where fb.catid == 1
                      select fb;

            Grid.DataSource = fbs;
            Grid.DataBind();
        }
        //for the selection of meanie kids
        else if (dropdownlist1.SelectedValue == "2")
        {
            var fbs = from fb in db.productsts
                      where fb.catid == 2
                      select fb;

            Grid.DataSource = fbs;
            Grid.DataBind();
        }
        //for the selection of animals with joints
        else if (dropdownlist1.SelectedValue == "3")
        {
            var fbs = from fb in db.productsts
                      where fb.catid == 3
                      select fb;

            Grid.DataSource = fbs;
            Grid.DataBind();
        }
        //for the selection of animals with out movable joints
        else if (dropdownlist1.SelectedValue == "4")
        {
            var fbs = from fb in db.productsts
                      where fb.catid == 4
                      select fb;

            Grid.DataSource = fbs;
            Grid.DataBind();
        }
        //for the selection of humans
        else if (dropdownlist1.SelectedValue == "5")
        {
            var fbs = from fb in db.productsts
                      where fb.catid == 5
                      select fb;

            Grid.DataSource = fbs;
            Grid.DataBind();
        }
    }

    protected void Grid_PageIndexChanged(object sender, EventArgs e)
    {

    }

    protected void Grid_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        Grid.PageIndex = e.NewPageIndex;
        Grid.DataBind();
    }
}